# -*- coding: utf-8 -*-
#!/bin/bash
echo ligando os agentes ...
gnome-terminal -- python3 Gerador.py
gnome-terminal -- python3 Resolvedor.py
